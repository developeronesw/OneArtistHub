function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}})}
const clean=(v,n=500)=>String(v??'').replace(/\0/g,'').slice(0,n)
function base64url(value){return btoa(typeof value==='string'?value:JSON.stringify(value)).replace(/=+$/,'').replace(/\+/g,'-').replace(/\//g,'_')}
function authAssertion(clientId,merchantId){return `${base64url({alg:'none'})}.${base64url({iss:clientId,payer_id:merchantId})}.`}
async function paypalAccess(env){
  const base=env.PAYPAL_ENV==='live'?'https://api-m.paypal.com':'https://api-m.sandbox.paypal.com';
  const token=btoa(`${env.PAYPAL_PARTNER_CLIENT_ID}:${env.PAYPAL_PARTNER_SECRET}`);
  const r=await fetch(base+'/v1/oauth2/token',{method:'POST',headers:{authorization:`Basic ${token}`,'content-type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials'});
  if(!r.ok)throw new Error('PayPal partner authentication failed.');
  const j=await r.json();return {base,token:j.access_token};
}
function authorized(req,env){return !!env.CONNECT_SHARED_SECRET&&req.headers.get('authorization')===`Bearer ${env.CONNECT_SHARED_SECRET}`}
function paypalHeaders(env,pp,merchantId,extra={}){
  const h={authorization:`Bearer ${pp.token}`,'content-type':'application/json',...extra};
  if(merchantId)h['PayPal-Auth-Assertion']=authAssertion(env.PAYPAL_PARTNER_CLIENT_ID,merchantId);
  if(env.PAYPAL_PARTNER_ATTRIBUTION_ID)h['PayPal-Partner-Attribution-Id']=env.PAYPAL_PARTNER_ATTRIBUTION_ID;
  return h;
}
async function paypalJson(env,path,{method='GET',merchantId='',body,requestId}={}){
  const pp=await paypalAccess(env),headers=paypalHeaders(env,pp,merchantId,requestId?{'paypal-request-id':clean(requestId,38)}:{}),r=await fetch(pp.base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  let j={};try{j=await r.json()}catch{}
  return {ok:r.ok,status:r.status,data:j};
}
export default {async fetch(req,env){
  try{
    const url=new URL(req.url);
    if(url.pathname==='/health')return json({ok:true,service:'OneArtist Connect',paypalEnvironment:env.PAYPAL_ENV==='live'?'live':'sandbox'});
    if(!authorized(req,env))return json({ok:false,error:'Unauthorized'},401);
    if(req.method==='GET'&&url.pathname==='/config'){const pp=await paypalAccess(env);return json({ok:true,clientId:clean(env.PAYPAL_PARTNER_CLIENT_ID,255),environment:env.PAYPAL_ENV==='live'?'live':'sandbox',webhookConfigured:!!(env.PAYPAL_WEBHOOK_ID_LIVE||env.PAYPAL_WEBHOOK_ID_SANDBOX||env.PAYPAL_WEBHOOK_ID),authenticated:!!pp.token});}
    if(req.method==='POST'&&url.pathname==='/onboard/start'){
      const b=await req.json(),trackingId=clean(b.trackingId,120),returnUrl=clean(b.returnUrl,1000);
      if(!trackingId||!/^https:\/\//i.test(returnUrl))return json({ok:false,error:'trackingId and HTTPS returnUrl are required.'},400);
      const pp=await paypalAccess(env);
      const payload={tracking_id:trackingId,partner_config_override:{return_url:returnUrl,return_url_description:'Return to OneArtist Hub'},operations:[{operation:'API_INTEGRATION',api_integration_preference:{rest_api_integration:{integration_method:'PAYPAL',integration_type:'THIRD_PARTY',third_party_details:{features:['PAYMENT','REFUND']}}}}],products:['EXPRESS_CHECKOUT'],legal_consents:[{type:'SHARE_DATA_CONSENT',granted:true}]};
      const headers={authorization:`Bearer ${pp.token}`,'content-type':'application/json'};if(env.PAYPAL_PARTNER_ATTRIBUTION_ID)headers['PayPal-Partner-Attribution-Id']=env.PAYPAL_PARTNER_ATTRIBUTION_ID;
      const r=await fetch(pp.base+'/v2/customer/partner-referrals',{method:'POST',headers,body:JSON.stringify(payload)});const j=await r.json();if(!r.ok)return json({ok:false,error:clean(j.message||'PayPal partner referral failed.',500),details:j.details||[]},r.status);
      const actionUrl=(j.links||[]).find(x=>x.rel==='action_url')?.href,self=(j.links||[]).find(x=>x.rel==='self')?.href;if(!actionUrl)return json({ok:false,error:'PayPal did not return an onboarding URL.'},502);
      return json({ok:true,actionUrl,self,trackingId},201);
    }
    if(req.method==='POST'&&url.pathname==='/onboard/status'){
      const b=await req.json(),merchantId=clean(b.merchantId,40),trackingId=clean(b.trackingId,120);
      if(!merchantId||!trackingId||!env.PAYPAL_PARTNER_ID)return json({ok:false,error:'merchantId, trackingId and PAYPAL_PARTNER_ID are required.'},400);
      const pp=await paypalJson(env,`/v1/customer/partners/${encodeURIComponent(env.PAYPAL_PARTNER_ID)}/merchant-integrations/${encodeURIComponent(merchantId)}`,{});
      if(!pp.ok)return json({ok:false,error:clean(pp.data.message||'Unable to verify merchant onboarding.',500)},pp.status);
      const j=pp.data;return json({ok:true,merchantId:j.merchant_id||merchantId,trackingId:j.tracking_id||trackingId,paymentsReceivable:!!j.payments_receivable,primaryEmailConfirmed:!!j.primary_email_confirmed,products:j.products||[],oauthIntegrations:j.oauth_integrations||[]});
    }
    if(req.method==='POST'&&url.pathname==='/paypal/create-order'){
      const b=await req.json(),merchantId=clean(b.merchantId,40),payload=b.payload||{};
      if(!merchantId||!payload?.purchase_units?.length)return json({ok:false,error:'merchantId and a valid order payload are required.'},400);
      payload.purchase_units=payload.purchase_units.map(u=>({...u,payee:{...(u.payee||{}),merchant_id:merchantId},payment_instruction:{...(u.payment_instruction||{}),disbursement_mode:'INSTANT'}}));
      const r=await paypalJson(env,'/v2/checkout/orders',{method:'POST',merchantId,body:payload,requestId:b.requestId});
      if(!r.ok||!r.data?.id)return json({ok:false,error:clean(r.data.message||'PayPal order creation failed.',500),details:r.data.details||[]},r.status||502);
      return json({ok:true,order:r.data},201);
    }
    if(req.method==='POST'&&url.pathname==='/paypal/order'){
      const b=await req.json(),merchantId=clean(b.merchantId,40),orderId=clean(b.orderId,80);if(!merchantId||!orderId)return json({ok:false,error:'merchantId and orderId are required.'},400);
      const r=await paypalJson(env,`/v2/checkout/orders/${encodeURIComponent(orderId)}`,{merchantId});if(!r.ok)return json({ok:false,error:clean(r.data.message||'PayPal order lookup failed.',500)},r.status||502);return json({ok:true,order:r.data});
    }
    if(req.method==='POST'&&url.pathname==='/paypal/capture'){
      const b=await req.json(),merchantId=clean(b.merchantId,40),orderId=clean(b.orderId,80);if(!merchantId||!orderId)return json({ok:false,error:'merchantId and orderId are required.'},400);
      const r=await paypalJson(env,`/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`,{method:'POST',merchantId,body:{},requestId:b.requestId});if(!r.ok)return json({ok:false,error:clean(r.data.message||'PayPal capture failed.',500),details:r.data.details||[]},r.status||502);return json({ok:true,order:r.data});
    }
    if(req.method==='POST'&&url.pathname==='/paypal/refund'){
      const b=await req.json(),merchantId=clean(b.merchantId,40),captureId=clean(b.captureId,80);if(!merchantId||!captureId)return json({ok:false,error:'merchantId and captureId are required.'},400);
      const r=await paypalJson(env,`/v2/payments/captures/${encodeURIComponent(captureId)}/refund`,{method:'POST',merchantId,body:b.payload||{},requestId:b.requestId});if(!r.ok||!['COMPLETED','PENDING'].includes(String(r.data.status||'').toUpperCase()))return json({ok:false,error:clean(r.data.message||'PayPal refund failed.',500),details:r.data.details||[]},r.status||502);return json({ok:true,refund:r.data});
    }
    if(req.method==='POST'&&url.pathname==='/paypal/webhook/verify'){
      const b=await req.json(),h=b.headers||{},rawBody=String(b.rawBody||'');if(!rawBody||!h.auth_algo||!h.cert_url||!h.transmission_id||!h.transmission_sig||!h.transmission_time)return json({ok:false,error:'PayPal webhook verification data is incomplete.'},400);let webhookEvent={};try{webhookEvent=JSON.parse(rawBody)}catch{return json({ok:false,error:'PayPal webhook body is invalid JSON.'},400);}
      const webhookId=env.PAYPAL_ENV==='live'?(env.PAYPAL_WEBHOOK_ID_LIVE||env.PAYPAL_WEBHOOK_ID):(env.PAYPAL_WEBHOOK_ID_SANDBOX||env.PAYPAL_WEBHOOK_ID);if(!webhookId)return json({ok:false,error:'PayPal webhook ID is not configured on the Connect worker.'},503);
      const pp=await paypalAccess(env),payload={auth_algo:h.auth_algo,cert_url:h.cert_url,transmission_id:h.transmission_id,transmission_sig:h.transmission_sig,transmission_time:h.transmission_time,webhook_id:webhookId,webhook_event:webhookEvent};
      const r=await fetch(pp.base+'/v1/notifications/verify-webhook-signature',{method:'POST',headers:{authorization:`Bearer ${pp.token}`,'content-type':'application/json'},body:JSON.stringify(payload)});let j={};try{j=await r.json()}catch{}if(!r.ok)return json({ok:false,error:clean(j.message||'PayPal webhook verification failed.',500)},r.status);return json({ok:true,verified:j.verification_status==='SUCCESS',status:j.verification_status||''});
    }
    return json({ok:false,error:'Not found'},404);
  }catch(e){return json({ok:false,error:clean(e?.message||e,500)},500)}
}}
