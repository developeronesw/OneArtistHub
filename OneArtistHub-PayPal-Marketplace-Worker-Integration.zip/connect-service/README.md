# OneArtist Connect — PayPal marketplace service

Deploy `paypal-worker.js` as a central Cloudflare Worker owned by Developer One. Do not ship PayPal platform secrets inside customer OneArtist installations.

## Required Worker secrets

- `PAYPAL_ENV` — `sandbox` or `live`
- `PAYPAL_PARTNER_CLIENT_ID` — PayPal platform REST client ID
- `PAYPAL_PARTNER_SECRET` — PayPal platform REST client secret
- `PAYPAL_PARTNER_ID` — PayPal partner ID
- `PAYPAL_PARTNER_ATTRIBUTION_ID` — optional PayPal BN code
- `PAYPAL_WEBHOOK_ID_SANDBOX` — sandbox webhook ID
- `PAYPAL_WEBHOOK_ID_LIVE` — live webhook ID
- `CONNECT_SHARED_SECRET` — secret used by OneArtist installations to authenticate to this Worker

## Artist installation secrets

Each OneArtist installation gets:

- `ONEARTIST_CONNECT_URL`
- `ONEARTIST_CONNECT_TOKEN`

The current Worker contract uses one shared bearer secret for the configured installations. If you later want per-installation token rotation, the Worker can be extended to map tokens to installation IDs.

## Endpoints

- `GET /health`
- `GET /config`
- `POST /onboard/start`
- `POST /onboard/status`
- `POST /paypal/create-order`
- `POST /paypal/order`
- `POST /paypal/capture`
- `POST /paypal/refund`
- `POST /paypal/webhook/verify`

The Worker authenticates to PayPal, generates the `PayPal-Auth-Assertion` for the connected seller, and keeps the platform Client Secret outside the artist installation. PayPal documents `PayPal-Auth-Assertion` as the marketplace/platform mechanism for making API calls on behalf of individual merchants.

## Seller onboarding

The Worker uses Partner Referrals with `EXPRESS_CHECKOUT` and `PAYMENT`/`REFUND` permissions. Seller onboarding is performed before payment, which is the PayPal-recommended flow and allows standard PayPal Checkout sellers to use personal accounts when the platform permits casual sellers.

OneArtist Hub does not configure a platform fee. Orders specify the connected seller as the payee and use instant disbursement so funds are routed directly to the seller rather than being collected and later paid out by OneArtist.
